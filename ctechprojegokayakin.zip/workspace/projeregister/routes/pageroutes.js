var express = require("express");  
var passport = require("passport");
var User             = require("../models/user");
var router          = express.Router();




/*Routes will starting here */
router.get("/", function(req, res) {
    res.render("home");
});



router.get("/index", function(req, res) {
   res.render("index");
});



 /* ================ login and register routes ================ */


/* LOGİN */



router.get("/login", function(req, res) {
       res.render("login");
});


  
router.post("/login", passport.authenticate("local", 
    {
        successRedirect: "/index",
        failureRedirect: "/login",
        
        
        
    }), function(req, res){
});




// ===================================================================================
/* Register Route */
router.get("/register", function(req, res) {
   res.render("register");
});


/* username:req.body.username register fonksiyonu kullanıldığı için 
    username olmadığı zaman hata alınır !*/
router.post("/register", function(req, res){
   var name =req.body.name;
   var surname =req.body.surname;
   var username =req.body.username;
   var email =req.body.email;
   
   var newUser = new User ({name: name, surname: surname, username:username, email: email});

   User.register(newUser, req.body.password, function(err, user) {
       if(err) {
           console.log(err);
           return res.render("register");
       } 
       passport.authenticate("local")(req, res, function (){
           req.flash("success", "Veri tabanına başarıyla kayıt oldunuz " + user.username);
           res.redirect("/index") ;
           
       });
   });
});


/*Logout -------- */

router.get("/logout", function(req, res) {
   req.logout();
   req.flash("error", "Oturum kapatıldı. Yine bekleriz ");
   res.redirect("/");
  
});


module.exports=router;