var express         = require("express"),
    app             = express(),
    bodyParser      = require("body-parser"),
    flash           = require("connect-flash"),
    mongoose        = require("mongoose"),
    passport        = require("passport"),
    LocalStrategy   = require("passport-local"),
    session         = require("express-session"),
    User            = require("./models/user");
    

//mongoose.connect("mongodb://localhost/ctech_proje_3");
mongoose.connect("mongodb://akingokay:gokay_1994@ds121575.mlab.com:21575/ctechproject");
//mongodb://akingokay:gokay_1994@ds121575.mlab.com:21575/ctechproject


var pageRoutes = require("./routes/pageroutes");


app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public"));
app.use(flash());

/* Passport configuration */
app.use(require("express-session")({
    secret: "secret is more important",
    resave: false,
    saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());


/* flash message and current user*/
app.use(function(req, res, next){
   /* current user */  
   res.locals.currentUser = req.user;
   res.locals.error = req.flash("error");
   res.locals.success = req.flash("success");
   next();
});
    


app.use("/",pageRoutes);


app.listen(process.env.PORT, process.env.IP, function() {
   console.log("Ctech Project server has started"); 
});